#Portal Link 
Open_Browser =               "https://have-your-say-admin-portal.have-your-say-v2-dev.rbb-banking.sdc-nonprod.caas.absa.co.za/login"
Browser =                    "chrome"

#Valid Credentials
Username =                      ""
Password =                      ""
#Invalid Credentials
Invalid_UN =                    "Password"
Invalid_Pw =                    "12345"

#Cost Center Number 
CostCenterCode =             "SA603039"

#DQ Question Input 
Dynamic_Question_Input =    "Demo- DQ- Free Text- 25 April 2023"
