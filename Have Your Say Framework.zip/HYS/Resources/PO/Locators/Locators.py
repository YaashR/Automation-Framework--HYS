# LoginPage locators
LoginUsernameInputBox =      name="name=username"
LoginPasswordInputBox =      id="id=login-password-input"
LoginButton =                id="id=loginbtn"

#LandingPage Locators
CreateSurvey =               id="//*[contains(text(),'Create Survey')]"

#TargetAudiencePage Locators 
CostCenterInput =            xpath="//*[@id=searchImage]"
InputCostCenter =            id="id=searchImage" 
CostCenterArea =             xpath="xpath=/html/body/app-root/app-createsurvey/body/div[4]/table/tbody[9]/tr/td/label"
CostCenterName =             xpath="xpath=//*[@id=SA603039]"
NextButton =                 xpath="xpath=/html/body/app-root/app-createsurvey/body/div[4]/button[2]"

#DQPage Locators
#Start and End Date Buttons:
StartDateIcon =              xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[1]/div[2]/mat-form-field/div/div[1]/div[2]"
EndDateIcon =                xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[1]/div[2]/div/mat-form-field/div/div[1]/div[2]/mat-datepicker-toggle"
#Dates
Start_Date =                 xpath="xpath=/html/body/div/div[2]/div/mat-datepicker-content/div[2]/mat-calendar/div/mat-month-view/table/tbody/tr[5]/td[3]/button/div[1]"
End_Date =                   xpath="xpath=/html/body/div/div[2]/div/mat-datepicker-content/div[2]/mat-calendar/div/mat-month-view/table/tbody/tr[5]/td[3]/button/div[1]"
#Question Field:
DqQuestionInputField =       name="name=obj.question"
#Answer Type:
Answer_Drop_Down =           xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[6]/div[1]"
Free_Txt =                   xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[6]/div[1]/div/label[2]"
DqPageHeading =              xpath="xpath=/html/body/app-root/app-createsurvey/body/app-topbar/div"
#Dq Preview
#Preview
Preview_Btn =                xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[5]/button"

#SummaryPage Locators 
Summary_Btn =                xpath="xpath=/html/body/app-root/app-createsurvey/body/div[2]/div/form/div[12]/button[2]"
Schedule_Btn =               xpath="xpath=//*[@id=submitQuestion]"

#Statement 

#Statement_Btn =             xpath=

#Mood
#Mood_Btn =                   xpath=/html/body/app-root/app-create-mood-survey/body/div[1]/button[1]